package com.example.hondaecuflasher

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.hoho.android.usbserial.driver.UsbSerialPort
import com.hoho.android.usbserial.driver.UsbSerialProber
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    companion object {
        private const val ACTION_USB_PERMISSION = "com.example.hondaecuflasher.USB_PERMISSION"
    }

    private lateinit var statusText: TextView
    private lateinit var logText: TextView
    private lateinit var btnConnect: Button

    private var usbSerialPort: UsbSerialPort? = null
    private var ecuProtocol: HondaEcuProtocol? = null

    private val usbReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (ACTION_USB_PERMISSION == intent.action) {
                val granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)
                if (granted) {
                    appendLog("ได้รับสิทธิ์ USB แล้ว กำลังเชื่อมต่อ...")
                    openConnection()
                } else {
                    appendLog("ผู้ใช้ไม่อนุญาตสิทธิ์ USB")
                    setStatus("ถูกปฏิเสธสิทธิ์ USB")
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)
        logText = findViewById(R.id.logText)
        btnConnect = findViewById(R.id.btnConnect)

        val filter = IntentFilter(ACTION_USB_PERMISSION)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(usbReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(usbReceiver, filter)
        }

        btnConnect.setOnClickListener {
            connectToDevice()
        }
    }

    private fun connectToDevice() {
        val usbManager = getSystemService(Context.USB_SERVICE) as UsbManager
        val availableDrivers = UsbSerialProber.getDefaultProber().findAllDrivers(usbManager)

        if (availableDrivers.isEmpty()) {
            appendLog("ไม่พบอุปกรณ์ USB ที่รองรับ")
            setStatus("ไม่พบอุปกรณ์")
            return
        }

        val driver = availableDrivers[0]
        val device: UsbDevice = driver.device

        if (!usbManager.hasPermission(device)) {
            appendLog("กำลังขอสิทธิ์เข้าถึง USB...")
            val permissionIntent = PendingIntent.getBroadcast(
                this, 0, Intent(ACTION_USB_PERMISSION),
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
                    PendingIntent.FLAG_MUTABLE
                else 0
            )
            usbManager.requestPermission(device, permissionIntent)
        } else {
            openConnection()
        }
    }

    private fun openConnection() {
        val usbManager = getSystemService(Context.USB_SERVICE) as UsbManager
        val availableDrivers = UsbSerialProber.getDefaultProber().findAllDrivers(usbManager)

        if (availableDrivers.isEmpty()) {
            appendLog("ไม่พบอุปกรณ์ USB")
            return
        }

        val driver = availableDrivers[0]
        val connection = usbManager.openDevice(driver.device)

        if (connection == null) {
            appendLog("เปิดการเชื่อมต่อ USB ไม่ได้")
            setStatus("เชื่อมต่อล้มเหลว")
            return
        }

        val port = driver.ports[0]
        try {
            port.open(connection)
            usbSerialPort = port
            ecuProtocol = HondaEcuProtocol(port)
            ecuProtocol?.configurePort()

            setStatus("เชื่อมต่อ USB สำเร็จ")
            appendLog("เปิดพอร์ตสำเร็จ เริ่ม init ECU...")

            initEcuAsync()
        } catch (e: Exception) {
            appendLog("เกิดข้อผิดพลาด: ${e.message}")
            setStatus("เชื่อมต่อล้มเหลว")
        }
    }

    private fun initEcuAsync() {
        lifecycleScope.launch {
            val success = ecuProtocol?.initEcu() ?: false
            if (success) {
                setStatus("ECU ตอบสนอง — พร้อมใช้งาน")
                appendLog("Init ECU สำเร็จ")
            } else {
                setStatus("ECU ไม่ตอบสนอง")
                appendLog("Init ECU ล้มเหลว ตรวจสอบสายและวงจรแปลงสัญญาณ")
            }
        }
    }

    private fun setStatus(text: String) {
        statusText.text = text
    }

    private fun appendLog(line: String) {
        logText.text = "${logText.text}\n$line"
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            usbSerialPort?.close()
        } catch (_: Exception) {
        }
        unregisterReceiver(usbReceiver)
    }
}
